#!/bin/sh
chmod +x game
./game